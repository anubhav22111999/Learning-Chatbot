# Brinks
Brinks is a learning chatbot created using C++ for windows platform.It intillegently handles various tasks and queries for the user providing a simple and easy to use experience to the user.It is completely offline supporting multiple login system.User can train brinks as per their convineince.

# Features
* Self Evolving
* Open Apps
* Play Games
* Chat


