#include<iostream>
#include<conio.h>

using namespace std;

{

    gotoxy(4,6);

    cout<<"hello world";
    getch();
}
