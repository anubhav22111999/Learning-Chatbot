#ifndef _VOICE_H
#define _VOICE_H

#include <iostream>

using namespace std;

class Voice {
public:
    void say(string phrase);    // Used to textually and audibly communicate a phrase
};

#endif
